##Frogger Arcade Game

**Goal**

The goal of this game is to move the character across the bricks towards the water with out colliding into the bugs that are moving horizontally across the screen.  

**Movement of character**

Users utilize left/right/up/down arrows on key pad to move character.

**Installation**
1.Download zipfile 
2.In the application's directory open the index.html file in a web browser window to being playing game  



**Resources**

(https://github.com/cpascual36/FEND-arcade-game/blob/master/js/app.js).
(https://github.com/alexsales/frontend-nanodegree-frogger-arcade-game/blob/frogger-arcade-master/js/app.js).
(https://www.smashingmagazine.com/2015/09/principles-of-html5-game-design/?utm_source=html5weekly&utm_).

